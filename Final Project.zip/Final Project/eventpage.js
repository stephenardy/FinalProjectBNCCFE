// const firebaseConfig = {
//     apiKey: "AIzaSyBlL6qAtifntM-U89jFw8Ad20JEJGFX1wg",
//     authDomain: "finalprojectbnccfe-136d9.firebaseapp.com",
//     projectId: "finalprojectbnccfe-136d9",
//     storageBucket: "finalprojectbnccfe-136d9.appspot.com",
//     messagingSenderId: "76869068683",
//     appId: "1:76869068683:web:b3d124ef19692bf27b718e",
//     measurementId: "G-16FH8P2EDN"
//   };
  
// Firebase.initializeApp(firebaseConfig);
// var firestore=firebase.firestore();

const submitBtn = document.getElementById('submit');

let userEmail = document.getElementById('email');
let userName = document.getElementById('name');
let userPhoneNumber = document.getElementById('phonenumber');
let userEventChosen = document.getElementById('event-chosen');

let Error1 = document.getElementById('error-msg1');
let Error2 = document.getElementById('error-msg2');
let Error3 = document.getElementById('error-msg3');

// const db=firestore.collection("FinalProjectBNCCFE")

submitBtn.onclick = function submit(){
// submitBtn.addEventListener('click',function(event){
//     event.preventDefault();
    Error1.innerText='';
    Error2.innerText='';
    Error3.innerText='';
    let userEmailInput = userEmail.value;
    let userNameInput = userName.value;
    let userPhoneNumberInput = userPhoneNumber.value;


    if(!(userEmailInput.includes('@'))||userEmailInput.length == 0){
        Error1.innerText='Email must be filled and include "@"';
    }
    else if(userNameInput.length == 0 || !(userNameInput.split(" ").length >2)){
        Error2.innerText='Name must be filled with minimum three characters'
    }
    else if(userPhoneNumberInput.length == 0 ||!(userPhoneNumberInput.startsWith('08')) || userPhoneNumberInput.length > 14){
        Error3.innerText='Phone Number must be filled with no more than 14 numbers and the first two digits start with "08"'
    }
    else{
        db.doc().set({
            Email: userEmailInput,
            Name: userNameInput,
            PhoneNumber: userPhoneNumberInput,
            EventChosen: userEventChosenInput,           
        }).then(function(){
            console.log("Data Submitted");
        });
        userEmail.value='';
        userName.value='';
        userPhoneNumber.value='';
        userEventChosen.value='';
        alert("Data successfully added!")
    }
    
}